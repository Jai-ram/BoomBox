class Constants{
  static const String app='App info';
  static const List<String> choices = <String>[app,];

}