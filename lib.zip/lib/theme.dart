import 'dart:ui';

const Color accentColor = const Color(0xFFf08f8f);
const Color lightAccentColor = const Color(0xFFFFAFAF);
const Color darkAccentColor = const Color(0xFFD06F6F);
const Color purplec = const Color(0xFFCC00CC);

